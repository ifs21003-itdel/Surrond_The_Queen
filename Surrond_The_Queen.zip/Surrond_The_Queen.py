import random
import tkinter as tk
from tkinter import ttk
from functools import partial


array = []
the_u = False
row_u = 0
column_u = 0
user_success = False
WIDTH = 400
HEIGHT = 400

window = tk.Tk()
canvas = tk.Canvas(window, width=WIDTH, height=HEIGHT, bg='grey')
canvas_input = tk.Canvas(canvas, bg='grey')
canvas_input.config(highlightthickness = 0)
label = ttk.Label(canvas)
label["text"] = "Masukkan jumlah bidak user (4 - 10)"
label_input_failure = ttk.Label(canvas)
label_input_failure["text"] = "Masukkan input sesuai rentang dari 4 hingga 10"
input_ukuran = tk.Entry(canvas_input, show=None, font=('Arial', 14))
button = tk.Button(canvas_input, text='Submit', command=lambda: initBlock(int(input_ukuran.get())))
queen_image = tk.PhotoImage(file="queen.png")
rook_image = tk.PhotoImage(file="rook.png")

canvas_board = tk.Canvas(window, width=WIDTH, height=HEIGHT)
canvas_win = tk.Canvas(window, width=WIDTH - 200, height=HEIGHT - 200)
label_win = ttk.Label(canvas_win)
label_win["text"] = "You Win!"
button_back = tk.Button(canvas_win, text='Back', command=lambda: restart())


def acak_posisi(ukuranPapan):
    return (random.randint(0, ukuranPapan - 1), random.randint(0, ukuranPapan - 1))

def initBlock(banyakBidak):
    global array
    if(banyakBidak >= 4 and banyakBidak <= 10):
        canvas.pack_forget()
        ukuranPapan = banyakBidak
        array = [["[   ]" for _ in range(ukuranPapan)] for _ in range(ukuranPapan)]
        # array = [["[   ]" for _ in range(ukuranPapan + 1)] for _ in range(ukuranPapan + 1)]
        posisi_q = (random.randint(0, ukuranPapan - 1), random.randint(0, ukuranPapan - 1))
        # posisi_q = (random.randint(0, ukuranPapan), random.randint(0, ukuranPapan))
        array[posisi_q[0]][posisi_q[1]] = "[ q ]"

        posisi_u = set()
        while len(posisi_u) < banyakBidak:
            posisi = acak_posisi(ukuranPapan)
            if (((abs(posisi_q[0] - posisi[0])) > 1 or (abs(posisi_q[1] - posisi[1])) > 1) and posisi not in posisi_u and posisi[0] != posisi_q[0] and posisi[1] != posisi_q[1]):
                posisi_u.add(posisi)

        for posisi in posisi_u:
            array[posisi[0]][posisi[1]] = "[ u ]"

        for baris in array:
            print(" ".join(baris))
            
        draw_board(array)
        canvas_board.pack()
    else:
        label_input_failure.pack(anchor=tk.CENTER, expand=True, padx='100', pady='10')
    return array


def checkHorizontal(arr, baris):
    heuristikH = 0
    for i in range(len(arr)):
        if '[ u ]' in arr[baris][i]:
            heuristikH += 1
    return heuristikH

def checkVertikal(arr, kolom):
    heuristikV = 0
    for i in range(len(arr)):
        if '[ u ]' in arr[i][kolom]:
            heuristikV += 1
    return heuristikV

def getHeuristik():
    global array
    baris, kolom = getIndex("[ q ]")
    heuristikMap = [["_" for _ in range(len(array))] for _ in range(len(array))]

    for i in range(len(heuristikMap)):
        heuristikMap[baris][i] = checkHorizontal(array, baris) + checkVertikal(array, i)

    for j in range(len(heuristikMap)):
        heuristikMap[j][kolom] = checkHorizontal(array, j) + checkVertikal(array, kolom)

    for i in range(len(heuristikMap)):
        for j in range(len(heuristikMap)):
            print(" " + str(heuristikMap[i][j]) + " ", end='')
            if j == (len(heuristikMap) - 1):
                print("\n")

    return heuristikMap

def get_array_size(arr):
    num_row = len(arr)
    num_column = len(arr[0]) if num_row > 0 else 0
    return num_row, num_column

def getIndex(bidak):
    global array
    posisibaris = 0
    posisikolom = 0
    baris, kolom = get_array_size(array)
    for i in range(baris):
        for j in range(kolom):
            if (array[i][j] == bidak):
                posisibaris = i
                posisikolom = j
                break
    return posisibaris, posisikolom

def move_the_q(heuristikMap):
    global canvas_board
    global array
    global user_success
    minimal_value = 0
    posisi = 0, 0
    move_to = []
    for i in range(len(heuristikMap)):
        for j in range(len(heuristikMap)):
            if (heuristikMap[i][j] == minimal_value):
                posisi = i, j
                move_to.append(posisi)

    if (len(move_to) > 0):
        posisi_q = getIndex("[ q ]")
        array[posisi_q[0]][posisi_q[1]] = "[   ]"
        posisi_q_new = move_to[random.randint(0, (len(move_to)) - 1)]
        array[posisi_q_new[0]][posisi_q_new[1]] = "[ q ]"
        for baris in array:
            print(" ".join(baris))
        user_success = False
        canvas_win.pack_forget()
        draw_board(array)
    else:
        user_success = True
        label_win.pack(anchor=tk.CENTER, expand=True, padx='20', pady='20')
        button_back.pack(anchor=tk.CENTER, expand=True, ipadx='10', ipady='10')
        canvas_win.pack(expand=True)
        canvas_board.unbind("<Button-1>")
        canvas_board.unbind("<Button-3>")
        print("You Win!")

def select_the_u(event):
    global row_u
    global column_u
    global the_u
    global array
    SIZE = WIDTH // len(array)
    row = event.y // SIZE
    column = event.x // SIZE
    while True:
        if ("[ u ]" in array[row][column]):
            select_user(row, column, SIZE)
            row_u = row
            column_u = column
            the_u = True
            break
        else :
            break

def move_the_u(event):
    global row_u
    global column_u
    global array
    SIZE = WIDTH // len(array)
    row = event.y // SIZE
    column = event.x // SIZE
    if ((((row) == (row_u) and (column) != (column_u)) or ((column) == (column_u) and (row) != (row_u))) and "[ u ]" not in array[row][column]):
        array[row_u][column_u] = "[   ]"
        array[row][column] = "[ u ]"
        draw_board(array)
        row_u = None
        column_u = None
        move_the_q(getHeuristik())
    else :
       move_the_u(event)
            
def restart():
    canvas_board.delete('all')
    canvas_win.pack_forget()
    canvas_board.pack_forget()
    canvas.pack(anchor=tk.CENTER, expand=True, padx='100', pady='10')
    canvas_board.bind("<Button-1>", lambda event: select_the_u(event))
    canvas_board.bind("<Button-3>", lambda event: move_the_u(event))
    

def draw_board(arr):
    SIZE = WIDTH // len(arr)
    colors = ["white", "gray"]
    for row in range(len(arr)):
        for column in range(len(arr)):
            x1 = column * SIZE
            y1 = row * SIZE
            x2 = x1 + SIZE
            y2 = y1 + SIZE
            color = colors[(row + column) % 2]
            canvas_board.create_rectangle(x1, y1, x2, y2, fill=color)
           
            if ("[ u ]" in arr[row][column]):
                place_user(row,column,arr)
            elif ("[ q ]" in arr[row][column]):
                place_queen(row,column,arr)
            
 
def place_queen(row, column, arr): 
    SIZE = WIDTH // len(arr) 
    x1 = column * SIZE
    y1 = row * SIZE
    canvas_board.create_image(x1 + SIZE/2, y1 + SIZE/2, image=queen_image)  
    canvas_board.image = queen_image 

def place_user(row, column, arr): 
    SIZE = WIDTH // len(arr) 
    x1 = column * SIZE
    y1 = row * SIZE
    canvas_board.create_image(x1 + SIZE/2, y1 + SIZE/2, image=rook_image)  
    canvas_board.image = rook_image 
    
def select_user(row, column, SIZE):
    global array
    x1 = column * SIZE
    y1 = row * SIZE
    x2 = x1 + SIZE
    y2 = y1 + SIZE
    canvas_board.create_rectangle(x1, y1, x2, y2, fill='red')
    place_user(row,column,array)
    
def select_user_move(event):
    global array
    SIZE = WIDTH // len(array)
    row = event.y // SIZE
    column = event.x // SIZE
    return row, column



def get_input():
    label.pack(anchor=tk.CENTER, expand=True, padx='100', pady='10')
    button.pack(expand=True, ipadx='10', ipady='10', padx='20', side=tk.RIGHT)
    input_ukuran.pack(expand=True, ipadx='10', ipady='10')
    canvas_input.pack(anchor=tk.CENTER, expand=True, padx='100', pady='10')
    canvas.pack(anchor=tk.CENTER ,expand=True)
    

window.title("Surround The Queen")
window.geometry('600x600')
window.resizable(False,False)
canvas_board.bind("<Button-1>", lambda event: select_the_u(event))
canvas_board.bind("<Button-3>", lambda event: move_the_u(event))
get_input()
window.mainloop()
